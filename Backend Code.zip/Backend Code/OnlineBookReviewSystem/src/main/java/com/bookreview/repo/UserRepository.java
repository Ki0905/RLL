package com.bookreview.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bookreview.pojo.UserDetails;



public interface UserRepository extends JpaRepository<UserDetails, Integer>{
	
	@Query("SELECT a FROM UserDetails a WHERE a.email = ?1")
	UserDetails findUserByEmail(String email);
	
	

}