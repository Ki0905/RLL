package com.bookreview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBookReviewSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookReviewSystemApplication.class, args);
	}

}
