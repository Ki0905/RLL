package com.bookreview;
import static org.junit.jupiter.api.Assertions.assertEquals;

 // Import the specific assertNull method


import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bookreview.pojo.Books;
import com.bookreview.service.BooksService;
@SpringBootTest
public class BooksAddingTest {

    @Autowired
    private BooksService booksService;

    @Test
    public void testAddProduct() {
      
        Books newBook = new Books();
        newBook.setName("Rich Dad Poor Dad");
        newBook.setAuthor("Robert");
        newBook.setPrice(150);
        newBook.setCategory("Finance");

        
        Books addedBook = booksService.addProduct(newBook);

        
        assertEquals(newBook.getName(), addedBook.getName());
        assertEquals(newBook.getAuthor(), addedBook.getAuthor());
        assertEquals(newBook.getPrice(), addedBook.getPrice());
        assertEquals(newBook.getCategory(), addedBook.getCategory());
    }
    
    
   
}
