package com.bookreview.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookreview.pojo.Admin;
import com.bookreview.pojo.UserDetails;
import com.bookreview.service.AdminService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/Admin")
public class AdminController {

	@Autowired
	AdminService adminservice;
	
	@PostMapping("/login")
	public Admin login(@RequestBody Admin admin)
	{
		String username=admin.getUsername(); 	
		Admin admin1= adminservice.getAdminbyusername(username);
		
		if(admin1 != null )  
			      return admin1;
		else
		          return null;
	
	}
	
	/*
	 * @PostMapping("/newregister") public Admin addUser(@RequestBody Admin admin) {
	 * Admin adminobj = adminservice.save(admin); return adminobj; }
	 */

		
		/*@PutMapping("/changepassword")
		public Admin ChangePassword(@RequestBody Map<String, String> request) {
		    String username = request.get("username");
		    String password = request.get("password");

		    Admin admin=adminservice.getAdminbyusername(username);
			if(username==admin.getUsername())
				    admin.setUsername(username);
				    admin.setPassword(password);
			        adminservice.save(admin);
			        return admin;*/
			       
		//}
	

	

}